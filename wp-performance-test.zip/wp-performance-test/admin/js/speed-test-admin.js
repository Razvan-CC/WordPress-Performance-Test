function analyze() {
 document.getElementById("s1").style.display = "none";
 document.getElementById("s2").style.display = "block";
}


