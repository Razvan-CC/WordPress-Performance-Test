<?php
class Speed_Test_i18n {
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'speed-test',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
