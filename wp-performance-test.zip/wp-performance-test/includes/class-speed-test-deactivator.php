<?php
class Speed_Test_Deactivator {
	public static function deactivate() {
	}

}
