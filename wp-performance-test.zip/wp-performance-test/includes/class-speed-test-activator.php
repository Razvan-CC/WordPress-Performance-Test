<?php
class Speed_Test_Activator {
	public static function activate() {

	}

}
